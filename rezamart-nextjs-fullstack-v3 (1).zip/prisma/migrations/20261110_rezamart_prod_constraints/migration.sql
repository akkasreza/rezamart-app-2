-- 1. Prevent Negative Stock on Product & ProductVariant
ALTER TABLE "Product"
  ADD CONSTRAINT "chk_product_stock_non_negative" CHECK ("stock" >= 0),
  ADD CONSTRAINT "chk_product_price_positive" CHECK ("price" >= 0),
  ADD CONSTRAINT "chk_product_sale_price_valid" CHECK ("salePrice" IS NULL OR ("salePrice" >= 0 AND "salePrice" <= "price"));

ALTER TABLE "ProductVariant"
  ADD CONSTRAINT "chk_variant_stock_non_negative" CHECK ("stock" IS NULL OR "stock" >= 0);

-- 2. Enforce Valid Review Rating (1 to 5)
ALTER TABLE "Review"
  ADD CONSTRAINT "chk_review_rating_range" CHECK ("rating" BETWEEN 1 AND 5);

-- 3. Enforce Positive Quantities on Orders, Stock Movements, Purchases & Returns
ALTER TABLE "OrderItem"
  ADD CONSTRAINT "chk_order_item_qty_positive" CHECK ("qty" > 0);

ALTER TABLE "StockMovement"
  ADD CONSTRAINT "chk_stock_movement_qty_non_negative" CHECK ("qty" >= 0);

ALTER TABLE "PurchaseOrderItem"
  ADD CONSTRAINT "chk_po_item_ordered_qty_positive" CHECK ("orderedQty" > 0),
  ADD CONSTRAINT "chk_po_item_received_qty_valid" CHECK ("receivedQty" >= 0 AND "receivedQty" <= "orderedQty");

ALTER TABLE "ReturnItem"
  ADD CONSTRAINT "chk_return_item_qty_positive" CHECK ("qty" > 0),
  ADD CONSTRAINT "chk_return_item_restocked_valid" CHECK ("restockedQty" >= 0 AND "restockedQty" <= "qty");

-- 4. Enforce Positive Refund Amount
ALTER TABLE "Refund"
  ADD CONSTRAINT "chk_refund_amount_positive" CHECK ("amount" > 0);

-- 5. Enforce Flash Sale Percentage Range (1 to 90)
ALTER TABLE "FlashSale"
  ADD CONSTRAINT "chk_flash_sale_pct_range" CHECK ("pct" BETWEEN 1 AND 90);
