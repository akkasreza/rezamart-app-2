const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Seeding initial categories and homepage sections...');

  const categories = [
    { slug: 'power-bank', nameBn: 'পাওয়ার ব্যাংক', sortOrder: 1 },
    { slug: 'headphones', nameBn: 'হেডফোন', sortOrder: 2 },
    { slug: 'accessories', nameBn: 'এক্সেসরিজ', sortOrder: 3 },
    { slug: 'mobile', nameBn: 'মোবাইল', sortOrder: 4 },
    { slug: 'mens-perfume', nameBn: 'মেনস পারফিউম', sortOrder: 5 },
    { slug: 'special', nameBn: 'স্পেশাল', sortOrder: 6 },
  ];

  for (const cat of categories) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: {},
      create: cat,
    });
  }

  const sections = [
    { key: 'hero', label: 'হিরো ব্যানার', enabled: true, sortOrder: 1 },
    { key: 'categories', label: 'ফিচার্ড ক্যাটাগরি', enabled: true, sortOrder: 2 },
    { key: 'flash', label: 'ফ্ল্যাশ সেল', enabled: true, sortOrder: 3 },
    { key: 'best', label: 'বেস্ট সেলিং', enabled: true, sortOrder: 4 },
    { key: 'new', label: 'নতুন পণ্য', enabled: true, sortOrder: 5 },
    { key: 'trending', label: 'ট্রেন্ডিং ও রিকমেন্ডেড', enabled: true, sortOrder: 6 },
    { key: 'why', label: 'কেন আমাদের বেছে নেবেন', enabled: true, sortOrder: 7 },
    { key: 'reviews', label: 'কাস্টমার রিভিউ', enabled: true, sortOrder: 8 },
    { key: 'delivery', label: 'ডেলিভারি তথ্য ও ট্রাস্ট ব্যাজ', enabled: true, sortOrder: 9 },
    { key: 'newsletter', label: 'নিউজলেটার', enabled: true, sortOrder: 10 },
  ];

  for (const sec of sections) {
    await prisma.homepageSection.upsert({
      where: { key: sec.key },
      update: {},
      create: sec,
    });
  }

  console.log('Seed completed successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
