# RezaMart Production Package (v2)

This package contains the complete, production-ready full-stack architecture for **rezamart.net**, matching all technical requirements from the Production Build Brief.

## ফোল্ডার স্ট্রাকচার ও ফিচারসমূহ:

1. **`prisma/schema.prisma`**
   - 8টি বিভাগ, 64টি জেলা, উপজেলা ও এরিয়া সহ পূর্ণাঙ্গ বাংলাদেশ অ্যাড্রেস মডেল।
   - WooCommerce `legacyOrderNumber` ও `displayNumber` ট্র্যাকিং।
   - Supplier Management (`ProductSupplier`, `PurchaseOrder`, `PurchaseOrderItem`)।
   - Returns ও Refunds ম্যানেজমেন্ট (`ReturnRequest`, `ReturnItem`, `Refund`)।
   - One-to-Many Shipment রিলেশন (`Shipment`, `ShipmentEvent`)।
   - Meta CAPI ও এসএমএস-এর জন্য Reliable Outbox (`OutboxEvent`, `WebhookInbox`)।
   - ওটিপি এবং অ্যাডমিন 2FA সিকিউরিটি (`OtpChallenge`, `TwoFactorRecoveryCode`)।

2. **`prisma/migrations/20261110_rezamart_prod_constraints/migration.sql`**
   - নেগেটিভ স্টক প্রতিরোধক `CHECK (stock >= 0)`।
   - রিভিউ রেটিং (1 to 5) ভ্যালিডেশন।
   - অর্ডার ও পারচেজ কোয়ান্টিটি পজিটিভ কনস্ট্রেইন্ট।

3. **`src/lib/`**
   - `prisma.ts`: গ্লোবাল সিঙ্গেলটন প্রিজমা ক্লায়েন্ট।
   - `auth-security.ts`: ওটিপি তৈরি, ভেরিফিকেশন, AES-256-GCM TOTP এনক্রিপশন ও সেশন বাতিল।
   - `inventory.ts`: `SELECT ... FOR UPDATE` রো-লক সহ স্টক ডিডাকশন ও রিস্টোরেশন।
   - `outbox.ts`: ডুপ্লিকেট রোধকারী ট্রানজ্যাকশনাল আউটবক্স প্রসেসর।
   - `address-and-legacy.ts`: পুরোনো WooCommerce অর্ডার ও বাংলাদেশি ফোন নম্বর ট্র্যাকিং।
   - `returns-and-suppliers.ts`: রিটার্ন অনুমোদন ও সাপ্লায়ার রিসিভিং লজিক।

4. **Next.js 15 & Tailwind UI**
   - সম্পূর্ণ বাংলা ফন্ট (`Anek Bangla` ও `Hind Siliguri`) কনফিগারেশন।
   - `tailwind.config.js`, `postcss.config.js`, `tsconfig.json` রেডি।

---

## চালানোর নিয়ম (Quick Setup):

```bash
# ১. ডিপেনডেন্সি ইনস্টল করুন
npm install

# ২. .env তৈরি করে আপনার Neon / PostgreSQL ডাটাবেস লিংক দিন
cp .env.example .env

# ৩. ডাটাবেসে টেবিলগুলো সরাসরি পুশ করুন
npx prisma db push

# ৪. প্রাথমিক ক্যাটাগরি ও সেটিংস সীড করুন
npm run db:seed

# ৫. অ্যাপ রান করুন
npm run dev
```
