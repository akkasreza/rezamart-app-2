import { NextResponse } from "next/server";
import { findOrderForTracking } from "@/lib/address-and-legacy";

export async function POST(req: Request) {
  try {
    const { orderNumber, phone } = await req.json();
    if (!orderNumber || !phone) {
      return NextResponse.json({ error: "অর্ডার নম্বর ও মোবাইল নম্বর দিন" }, { status: 400 });
    }
    try {
      const order = await findOrderForTracking(orderNumber, phone);
      if (order) {
        return NextResponse.json({
          found: true,
          displayNumber: order.displayNumber,
          customerName: order.customerName,
          status: order.status,
          total: Number(order.total),
          address: order.address,
        });
      }
    } catch (_) {
      // Ignore if DB table not pushed yet
    }
    return NextResponse.json(
      { found: false, error: "এই অর্ডার নম্বর ও মোবাইল নম্বরে কোনো অর্ডার খুঁজে পাওয়া যায়নি।" },
      { status: 404 }
    );
  } catch (err: any) {
    return NextResponse.json({ error: "ট্র্যাকিং তথ্যে ত্রুটি হয়েছে" }, { status: 500 });
  }
}
