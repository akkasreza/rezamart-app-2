import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "রেজা মার্ট | সেরা দামে অনলাইন শপিং",
  description: "প্রিমিয়াম কোয়ালিটি গ্যাজেট, পারফিউম ও দৈনন্দিন পণ্য সরাসরি আপনার দরজায়। ক্যাশ অন ডেলিভারি ও দ্রুত ডেলিভারি।",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="bn">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Anek+Bangla:wght@500;700;800&family=Hind+Siliguri:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-siliguri bg-rm-bg text-rm-ink min-h-screen antialiased">
        {children}
      </body>
    </html>
  );
}
