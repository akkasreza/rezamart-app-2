"use client";

import React, { useState } from "react";

interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  oldPrice: number;
  icon: string;
  stock: number;
}

const INITIAL_PRODUCTS: ProductItem[] = [
  { id: "p1", name: "Baseus 20000mAh 22.5W ফাস্ট চার্জিং পাওয়ার ব্যাংক", category: "পাওয়ার ব্যাংক", price: 1650, oldPrice: 2200, icon: "🔋", stock: 24 },
  { id: "p2", name: "AI ট্রান্সলেশন ওয়্যারলেস ইয়ারফোন (ANC Pro)", category: "হেডফোন", price: 1490, oldPrice: 2100, icon: "🎧", stock: 18 },
  { id: "p3", name: "প্রিমিয়াম মিক্সড ড্রাই ফ্রুটস ও হানি নাটস (৫০০ গ্রাম)", category: "স্পেশাল", price: 890, oldPrice: 1150, icon: "🍯", stock: 40 },
  { id: "p4", name: "আমির আল উদ ও কস্তুরী আতর কম্বো প্যাক", category: "মেনস পারফিউম", price: 650, oldPrice: 950, icon: "🌸", stock: 35 },
  { id: "p5", name: "৪জি এলটিই সিম সাপোর্টেড সিকিউরিটি সিসিটিভি ক্যামেরা", category: "এক্সেসরিজ", price: 2850, oldPrice: 3500, icon: "📷", stock: 12 },
  { id: "p6", name: "স্মার্ট ওয়াচ আল্ট্রা কলিং ও হেলথ ট্র্যাকার", category: "এক্সেসরিজ", price: 1350, oldPrice: 1850, icon: "⌚", stock: 29 },
  { id: "p7", name: "সৌদি স্টাইল প্রিমিয়াম জুব্বা ও পাঞ্জাবি ফ্যাব্রিক", category: "স্পেশাল", price: 1550, oldPrice: 1950, icon: "🕌", stock: 15 },
  { id: "p8", name: "টাইপ-সি ৬৫ ওয়াট সুপার ফাস্ট চার্জার অ্যাডাপ্টার", category: "মোবাইল", price: 750, oldPrice: 1050, icon: "🔌", stock: 50 },
];

const CATEGORIES = ["সকল পণ্য", "পাওয়ার ব্যাংক", "হেডফোন", "এক্সেসরিজ", "মোবাইল", "মেনস পারফিউম", "স্পেশাল"];

export default function RezaMartStorefront() {
  const [selectedCat, setSelectedCat] = useState("সকল পণ্য");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<Array<{ item: ProductItem; qty: number }>>([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [trackOpen, setTrackOpen] = useState(false);

  // Checkout states
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [division, setDivision] = useState("চট্টগ্রাম");
  const [district, setDistrict] = useState("খাগড়াছড়ি");
  const [upazila, setUpazila] = useState("");
  const [area, setArea] = useState<"DHAKA" | "OUTSIDE_DHAKA">("OUTSIDE_DHAKA");
  const [address, setAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<any>(null);

  // Tracking states
  const [trackOrderNum, setTrackOrderNum] = useState("");
  const [trackPhone, setTrackPhone] = useState("");
  const [trackResult, setTrackResult] = useState<any>(null);

  const filteredProducts = INITIAL_PRODUCTS.filter((p) => {
    const matchCat = selectedCat === "সকল পণ্য" || p.category === selectedCat;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const addToCart = (product: ProductItem, openModal = false) => {
    setCart((prev) => {
      const found = prev.find((x) => x.item.id === product.id);
      if (found) {
        return prev.map((x) => (x.item.id === product.id ? { ...x, qty: x.qty + 1 } : x));
      }
      return [...prev, { item: product, qty: 1 }];
    });
    if (openModal) {
      setOrderSuccess(null);
      setCheckoutOpen(true);
    }
  };

  const subtotal = cart.reduce((s, c) => s + c.item.price * c.qty, 0);
  const deliveryFee = area === "DHAKA" ? 70 : 120;
  const grandTotal = subtotal + (cart.length > 0 ? deliveryFee : 0);

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setSubmitting(true);
    setOrderSuccess(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          phone,
          division,
          district,
          upazila,
          area,
          address,
          items: cart.map((c) => ({ id: c.item.id, name: c.item.name, price: c.item.price, qty: c.qty })),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setOrderSuccess(data);
        setCart([]);
      } else {
        alert(data.error || "অর্ডার সম্পন্ন করা যায়নি");
      }
    } catch (err) {
      alert("নেটওয়ার্ক ত্রুটি, আবার চেষ্টা করুন");
    } finally {
      setSubmitting(false);
    }
  };

  const handleTrackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrackResult({ loading: true });
    try {
      const res = await fetch("/api/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderNumber: trackOrderNum, phone: trackPhone }),
      });
      const data = await res.json();
      setTrackResult(data);
    } catch {
      setTrackResult({ error: "ট্র্যাকিং তথ্য লোড করা যায়নি" });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-rm-bg text-rm-ink">
      {/* Top Bar */}
      <div className="bg-rm-900 text-rm-100 text-xs py-2 px-4">
        <div className="max-w-6xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <span>🚚 সারা বাংলাদেশে ক্যাশ অন ডেলিভারি | শতভাগ অরিজিনাল পণ্যের নিশ্চয়তা</span>
          <div className="flex items-center gap-4">
            <button onClick={() => setTrackOpen(true)} className="hover:text-rm-sun font-semibold">
              📦 অর্ডার ট্র্যাক করুন
            </button>
            <span>🌐 rezamart.net</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-rm-800 text-white sticky top-0 z-40 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setSelectedCat("সকল পণ্য")}>
            <div className="w-10 h-10 rounded-xl bg-rm-sun text-rm-900 font-extrabold text-2xl flex items-center justify-center">
              র
            </div>
            <div>
              <span className="text-2xl font-extrabold tracking-tight block leading-none">রেজা মার্ট</span>
              <span className="text-[11px] text-rm-200">বিশ্বস্ত অনলাইন শপিং</span>
            </div>
          </div>

          <div className="flex-1 max-w-md">
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="পণ্য খুঁজুন (পাওয়ার ব্যাংক, হেডফোন, আতর)..."
              className="w-full px-4 py-2 rounded-full text-rm-ink text-sm focus:outline-none focus:ring-2 focus:ring-rm-sun"
            />
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setTrackOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-sm font-semibold"
            >
              📦 ট্র্যাকিং
            </button>
            <button
              onClick={() => setCheckoutOpen(true)}
              className="px-4 py-2 rounded-xl bg-rm-sun hover:bg-rm-sun2 text-rm-900 font-extrabold text-sm flex items-center gap-2"
            >
              <span>🛒 কার্ট</span>
              <span className="bg-rm-900 text-rm-sun px-2 py-0.5 rounded-full text-xs">
                {cart.reduce((s, c) => s + c.qty, 0)}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Category Pills */}
      <div className="bg-white border-b border-rm-line">
        <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center gap-2 overflow-x-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCat(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition ${
                selectedCat === cat ? "bg-rm-800 text-rm-sun" : "bg-rm-bg text-rm-ink hover:bg-rm-100"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6 flex-1 w-full">
        {/* Hero Banner */}
        <section className="rounded-3xl bg-gradient-to-r from-rm-900 via-rm-800 to-rm-600 text-white p-7 md:p-10 mb-8 shadow-lg grid md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-2">
            <span className="inline-block bg-rm-sun/20 text-rm-sun border border-rm-sun/40 px-3 py-1 rounded-full text-xs font-bold mb-3">
              🔥 রেজা মার্ট স্পেশাল ধামাকা অফার
            </span>
            <h1 className="text-2xl md:text-4xl font-extrabold mb-3 leading-snug">
              প্রিমিয়াম গ্যাজেট, আতর ও নিত্যপ্রয়োজনীয় পণ্যে বিশেষ ছাড়!
            </h1>
            <p className="text-rm-200 text-sm md:text-base mb-5 max-w-xl">
              অগ্রিম এক টাকাও পেমেন্ট করতে হবে না। পণ্য হাতে পেয়ে যাচাই করে ডেলিভারি ম্যানের কাছে মূল্য পরিশোধ করুন।
            </p>
            <a
              href="#products"
              className="inline-block bg-rm-sun hover:bg-rm-sun2 text-rm-900 font-extrabold px-6 py-3 rounded-xl text-sm shadow"
            >
              🛍️ এখনই অর্ডার করুন
            </a>
          </div>
          <div className="bg-white/10 border border-white/15 rounded-2xl p-5 text-center backdrop-blur">
            <div className="text-4xl mb-2">⚡</div>
            <h3 className="text-lg font-extrabold text-rm-sun mb-1">১-ক্লিক ইজি অর্ডার</h3>
            <p className="text-xs text-rm-100">
              নাম, মোবাইল নম্বর ও ঠিকানা দিলেই মাত্র ৩০ সেকেন্ডে আপনার অর্ডার কনফার্ম!
            </p>
          </div>
        </section>

        {/* Product Grid */}
        <section id="products" className="mb-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl md:text-2xl font-extrabold text-rm-900">
              🌟 জনপ্রিয় পণ্যসমূহ ({filteredProducts.length})
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5">
            {filteredProducts.map((p) => {
              const disc = Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
              return (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl border border-rm-line overflow-hidden shadow-sm hover:shadow-md transition flex flex-col relative"
                >
                  {disc > 0 && (
                    <span className="absolute top-3 left-3 bg-rm-red text-white text-xs font-extrabold px-2.5 py-1 rounded-full">
                      -{disc}% ছাড়
                    </span>
                  )}
                  <div className="h-44 bg-rm-100 flex items-center justify-center text-6xl">{p.icon}</div>
                  <div className="p-4 flex-1 flex flex-col">
                    <span className="text-xs text-rm-mut mb-1">{p.category}</span>
                    <h3 className="font-bold text-sm text-rm-ink mb-2 line-clamp-2">{p.name}</h3>
                    <div className="mt-auto mb-3 flex items-baseline gap-2">
                      <span className="text-lg font-extrabold text-rm-600">৳{p.price}</span>
                      <span className="text-xs text-rm-mut line-through">৳{p.oldPrice}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => addToCart(p, true)}
                        className="bg-rm-800 hover:bg-rm-600 text-white font-bold py-2 px-2 rounded-xl text-xs"
                      >
                        ⚡ অর্ডার করুন
                      </button>
                      <button
                        onClick={() => addToCart(p, false)}
                        className="bg-rm-100 hover:bg-rm-200 text-rm-800 font-bold py-2 px-2 rounded-xl text-xs"
                      >
                        + কার্টে রাখুন
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </main>

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 max-h-[92vh] overflow-y-auto shadow-2xl">
            <div className="flex justify-between items-center pb-3 border-b border-rm-line mb-4">
              <h3 className="text-lg font-extrabold text-rm-900">🛍️ ক্যাশ অন ডেলিভারিতে অর্ডার করুন</h3>
              <button onClick={() => setCheckoutOpen(false)} className="text-rm-mut hover:text-rm-ink text-xl">
                ✕
              </button>
            </div>

            {orderSuccess ? (
              <div className="bg-rm-100 border border-rm-600 rounded-xl p-4 text-center">
                <div className="text-4xl mb-2">🎉</div>
                <h4 className="font-extrabold text-lg text-rm-900 mb-1">আলহামদুলিল্লাহ! অর্ডার সম্পন্ন হয়েছে</h4>
                <p className="text-sm text-rm-ink mb-2">
                  আপনার অর্ডার নম্বর: <strong className="text-rm-600">{orderSuccess.orderNumber}</strong>
                </p>
                <p className="text-xs text-rm-mut mb-4">মোট প্রদেয়: ৳{orderSuccess.total} (পণ্য হাতে পেয়ে পরিশোধ)</p>
                <button
                  onClick={() => {
                    setOrderSuccess(null);
                    setCheckoutOpen(false);
                  }}
                  className="bg-rm-800 text-white font-bold px-5 py-2 rounded-xl text-sm"
                >
                  ঠিক আছে
                </button>
              </div>
            ) : cart.length === 0 ? (
              <p className="text-center text-rm-mut py-6">আপনার কার্টে কোনো পণ্য নেই।</p>
            ) : (
              <form onSubmit={handleOrderSubmit} className="space-y-3">
                <div className="bg-rm-bg p-3 rounded-xl text-xs space-y-1.5">
                  {cart.map((c) => (
                    <div key={c.item.id} className="flex justify-between">
                      <span>
                        {c.item.name} × {c.qty}
                      </span>
                      <strong>৳{c.item.price * c.qty}</strong>
                    </div>
                  ))}
                  <div className="border-t border-rm-line pt-1.5 flex justify-between">
                    <span>ডেলিভারি চার্জ:</span>
                    <strong>৳{deliveryFee}</strong>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-rm-800">
                    <span>সর্বমোট:</span>
                    <span>৳{grandTotal}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1">আপনার নাম *</label>
                  <input
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="সম্পূর্ণ নাম লিখুন"
                    className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">মোবাইল নম্বর (১১ ডিজিট) *</label>
                  <input
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold mb-1">বিভাগ *</label>
                    <input
                      required
                      value={division}
                      onChange={(e) => setDivision(e.target.value)}
                      className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold mb-1">জেলা *</label>
                    <input
                      required
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold mb-1">উপজেলা / থানা *</label>
                    <input
                      required
                      value={upazila}
                      onChange={(e) => setUpazila(e.target.value)}
                      placeholder="উপজেলা লিখুন"
                      className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold mb-1">ডেলিভারি জোন *</label>
                    <select
                      value={area}
                      onChange={(e) => setArea(e.target.value as "DHAKA" | "OUTSIDE_DHAKA")}
                      className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                    >
                      <option value="DHAKA">ঢাকার ভেতরে (৳৭০)</option>
                      <option value="OUTSIDE_DHAKA">ঢাকার বাইরে (৳১২০)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">বিস্তারিত ঠিকানা *</label>
                  <textarea
                    required
                    rows={2}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="গ্রাম/মহল্লা, রোড, বাজার..."
                    className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-rm-sun hover:bg-rm-sun2 text-rm-900 font-extrabold py-3 rounded-xl text-sm"
                >
                  {submitting ? "অর্ডার প্রসেস হচ্ছে..." : "✅ অর্ডার কনফার্ম করুন (ক্যাশ অন ডেলিভারি)"}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Order Tracking Modal */}
      {trackOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex justify-between items-center pb-3 border-b border-rm-line mb-4">
              <h3 className="text-lg font-extrabold text-rm-900">📦 অর্ডার ট্র্যাকিং</h3>
              <button onClick={() => setTrackOpen(false)} className="text-rm-mut hover:text-rm-ink text-xl">
                ✕
              </button>
            </div>
            <form onSubmit={handleTrackSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold mb-1">অর্ডার নম্বর (যেমন: RM-123456)</label>
                <input
                  required
                  value={trackOrderNum}
                  onChange={(e) => setTrackOrderNum(e.target.value)}
                  placeholder="RM-XXXXXX"
                  className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">মোবাইল নম্বর</label>
                <input
                  required
                  value={trackPhone}
                  onChange={(e) => setTrackPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full border border-rm-line rounded-xl px-3 py-2 text-sm"
                />
              </div>
              <button type="submit" className="w-full bg-rm-800 text-white font-bold py-2.5 rounded-xl text-sm">
                🔍 অবস্থা দেখুন
              </button>
            </form>
            {trackResult && (
              <div className="mt-4 p-3 rounded-xl bg-rm-bg text-xs">
                {trackResult.loading ? (
                  <p>খোঁজা হচ্ছে...</p>
                ) : trackResult.found ? (
                  <div className="space-y-1">
                    <div>
                      <strong>অর্ডার:</strong> {trackResult.displayNumber}
                    </div>
                    <div>
                      <strong>গ্রাহক:</strong> {trackResult.customerName}
                    </div>
                    <div>
                      <strong>স্ট্যাটাস:</strong> <span className="text-rm-600 font-bold">{trackResult.status}</span>
                    </div>
                    <div>
                      <strong>মোট:</strong> ৳{trackResult.total}
                    </div>
                  </div>
                ) : (
                  <p className="text-rm-red font-bold">{trackResult.error}</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-rm-900 text-rm-200 py-8 px-4 text-center text-xs mt-12">
        <div className="max-w-6xl mx-auto">
          <p className="font-bold text-white text-sm mb-1">রেজা মার্ট (Reza Mart) — rezamart.net</p>
          <p>© {new Date().getFullYear()} সর্বস্বত্ব সংরক্ষিত | পরিচালক: মুহাম্মদ আক্কাস রেজা</p>
        </div>
      </footer>
    </div>
  );
}
