import { prisma } from "./prisma";
import { Prisma, ReturnStatus, PurchaseOrderStatus } from "@prisma/client";

export async function approveReturnRequest(
  tx: Prisma.TransactionClient,
  returnRequestId: string,
  adminUserId: string
) {
  const rma = await tx.returnRequest.findUnique({
    where: { id: returnRequestId },
    include: { items: { include: { orderItem: true } }, order: true },
  });
  if (!rma) throw new Error("রিটার্ন রিকোয়েস্ট পাওয়া যায়নি");

  const updatedRma = await tx.returnRequest.update({
    where: { id: returnRequestId },
    data: {
      status: ReturnStatus.RECEIVED,
      approvedBy: adminUserId,
      approvedAt: new Date(),
      receivedAt: new Date(),
    },
  });

  if (rma.restockItems) {
    for (const item of rma.items) {
      if (!item.orderItem.productId) continue;
      const idempotencyKey = `return:${rma.id}:item:${item.id}:restock`;

      const existingMove = await tx.stockMovement.findUnique({ where: { idempotencyKey } });
      if (existingMove) continue;

      const prod = await tx.product.update({
        where: { id: item.orderItem.productId },
        data: { stock: { increment: item.qty } },
      });

      await tx.stockMovement.create({
        data: {
          idempotencyKey,
          productId: item.orderItem.productId,
          variantId: item.orderItem.variantId,
          orderId: rma.orderId,
          returnRequestId: rma.id,
          type: "IN",
          qty: item.qty,
          balanceAfter: prod.stock,
          note: `রিটার্ন সম্পন্ন: RMA ${rma.rmaNumber}`,
        },
      });

      await tx.returnItem.update({
        where: { id: item.id },
        data: { restockedQty: item.qty },
      });
    }
  }

  return updatedRma;
}

export async function receivePurchaseOrder(
  tx: Prisma.TransactionClient,
  purchaseOrderId: string
) {
  const po = await tx.purchaseOrder.findUnique({
    where: { id: purchaseOrderId },
    include: { items: true },
  });
  if (!po) throw new Error("পারচেজ অর্ডার পাওয়া যায়নি");

  for (const item of po.items) {
    const idempotencyKey = `po:${po.id}:item:${item.id}:receive`;
    const existing = await tx.stockMovement.findUnique({ where: { idempotencyKey } });
    if (existing) continue;

    const qtyToReceive = item.orderedQty - item.receivedQty;
    if (qtyToReceive <= 0) continue;

    const prod = await tx.product.update({
      where: { id: item.productId },
      data: {
        stock: { increment: qtyToReceive },
        costPrice: item.unitCost,
      },
    });

    if (item.variantId) {
      await tx.productVariant.updateMany({
        where: { id: item.variantId, NOT: { stock: null } },
        data: { stock: { increment: qtyToReceive } },
      });
    }

    await tx.stockMovement.create({
      data: {
        idempotencyKey,
        productId: item.productId,
        variantId: item.variantId,
        purchaseOrderId: po.id,
        type: "IN",
        qty: qtyToReceive,
        balanceAfter: prod.stock,
        note: `সাপ্লায়ার সরবরাহ গ্রহণ: PO ${po.poNumber}`,
      },
    });

    await tx.purchaseOrderItem.update({
      where: { id: item.id },
      data: { receivedQty: item.orderedQty },
    });
  }

  return tx.purchaseOrder.update({
    where: { id: purchaseOrderId },
    data: {
      status: PurchaseOrderStatus.RECEIVED,
      receivedAt: new Date(),
    },
  });
}
