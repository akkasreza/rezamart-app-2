import crypto from "crypto";
import argon2 from "argon2";
import { prisma } from "./prisma";
import { OtpPurpose } from "@prisma/client";

const ENC_KEY_HEX = process.env.APP_ENCRYPTION_KEY || "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
const ENC_KEY = Buffer.from(ENC_KEY_HEX, "hex");

export function encryptSecret(plainText: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", ENC_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return `${iv.toString("hex")}:${authTag.toString("hex")}:${encrypted.toString("hex")}`;
}

export function decryptSecret(cipherText: string): string {
  const [ivHex, tagHex, dataHex] = cipherText.split(":");
  const decipher = crypto.createDecipheriv("aes-256-gcm", ENC_KEY, Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  return decipher.update(Buffer.from(dataHex, "hex"), undefined, "utf8") + decipher.final("utf8");
}

export async function issueOtpChallenge(phone: string, purpose: OtpPurpose, ip?: string) {
  const now = new Date();
  const existing = await prisma.otpChallenge.findFirst({
    where: { phone, purpose, consumedAt: null, expiresAt: { gt: now } },
    orderBy: { createdAt: "desc" },
  });

  if (existing) {
    if (existing.lockedUntil && existing.lockedUntil > now) {
      throw new Error("অতিরিক্ত ভুল চেষ্টার কারণে ওটিপি সাময়িকভাবে লক করা হয়েছে।");
    }
    if (existing.resendCount >= existing.maxResends) {
      throw new Error("ওটিপি পুনরায় পাঠানোর সীমা অতিক্রম করেছে। কিছুক্ষণ পর চেষ্টা করুন।");
    }
    if (now.getTime() - existing.lastSentAt.getTime() < 60_000) {
      throw new Error("নতুন ওটিপি পেতে অন্তত ৬০ সেকেন্ড অপেক্ষা করুন।");
    }
  }

  const rawOtp = crypto.randomInt(100000, 999999).toString();
  const codeHash = await argon2.hash(rawOtp);
  const expiresAt = new Date(now.getTime() + 5 * 60 * 1000);

  const challenge = existing
    ? await prisma.otpChallenge.update({
        where: { id: existing.id },
        data: { codeHash, expiresAt, resendCount: { increment: 1 }, lastSentAt: now },
      })
    : await prisma.otpChallenge.create({
        data: { phone, purpose, codeHash, expiresAt, ip },
      });

  return { challengeId: challenge.id, rawOtp };
}

export async function verifyOtpChallenge(challengeId: string, submittedCode: string) {
  const now = new Date();
  const ch = await prisma.otpChallenge.findUnique({ where: { id: challengeId } });

  if (!ch || ch.consumedAt || ch.expiresAt < now) {
    throw new Error("ওটিপি কোডটির মেয়াদ শেষ বা সঠিক নয়।");
  }
  if (ch.lockedUntil && ch.lockedUntil > now) {
    throw new Error("অ্যাকাউন্ট সুরক্ষায় ১৫ মিনিটের জন্য ওটিপি যাচাই লক করা হয়েছে।");
  }

  const isValid = await argon2.verify(ch.codeHash, submittedCode);
  if (!isValid) {
    const nextAttempts = ch.attempts + 1;
    const lock = nextAttempts >= ch.maxAttempts ? new Date(now.getTime() + 15 * 60 * 1000) : null;
    await prisma.otpChallenge.update({
      where: { id: ch.id },
      data: { attempts: nextAttempts, lockedUntil: lock },
    });
    throw new Error(`ভুল ওটিপি কোড। বাকি চেষ্টা: ${Math.max(0, ch.maxAttempts - nextAttempts)}`);
  }

  await prisma.otpChallenge.update({
    where: { id: ch.id },
    data: { consumedAt: now },
  });
  return ch;
}

export async function revokeAllUserSessions(userId: string, actorId: string, reason = "logout_everywhere") {
  return prisma.$transaction([
    prisma.user.update({
      where: { id: userId },
      data: { sessionVersion: { increment: 1 } },
    }),
    prisma.session.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date(), revokedReason: reason },
    }),
    prisma.activityLog.create({
      data: {
        userId: actorId,
        action: "auth.session.revoke_all",
        entity: "User",
        entityId: userId,
        meta: { reason },
      },
    }),
  ]);
}
