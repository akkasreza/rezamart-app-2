import { prisma } from "./prisma";

export async function findOrderForTracking(orderInput: string, rawPhone: string) {
  const cleanOrder = orderInput.trim().replace(/^#/, "").toUpperCase();
  const cleanPhone = rawPhone.replace(/[\s-]/g, "");

  return prisma.order.findFirst({
    where: {
      phone: cleanPhone,
      OR: [
        { displayNumber: { equals: cleanOrder, mode: "insensitive" } },
        { legacyOrderNumber: { equals: cleanOrder, mode: "insensitive" } },
        { id: cleanOrder },
      ],
    },
    include: {
      items: true,
      history: { orderBy: { at: "asc" } },
      shipments: { where: { isActive: true }, include: { events: { orderBy: { at: "desc" } } } },
    },
  });
}
