import { prisma } from "./prisma";

export async function enqueueOutboxEvent(
  tx: Parameters<Parameters<typeof prisma.$transaction>[0]>[0],
  params: { dedupeKey: string; topic: string; aggregateId: string; payload: object }
) {
  return tx.outboxEvent.upsert({
    where: { dedupeKey: params.dedupeKey },
    update: {},
    create: {
      dedupeKey: params.dedupeKey,
      topic: params.topic,
      aggregateId: params.aggregateId,
      payload: params.payload,
      status: "PENDING",
    },
  });
}

export async function processPendingOutboxBatch(batchSize = 25) {
  const now = new Date();
  const events = await prisma.outboxEvent.findMany({
    where: {
      status: { in: ["PENDING", "FAILED"] },
      nextRetryAt: { lte: now },
    },
    orderBy: { createdAt: "asc" },
    take: batchSize,
  });

  for (const ev of events) {
    try {
      await prisma.outboxEvent.update({
        where: { id: ev.id },
        data: { status: "PROCESSING", lockedAt: now },
      });

      if (ev.topic === "META_CAPI") {
        const order = await prisma.order.findUnique({ where: { id: ev.aggregateId } });
        if (order && !order.purchaseSentAt) {
          await prisma.order.update({
            where: { id: order.id },
            data: { purchaseSentAt: new Date() },
          });
        }
      }

      await prisma.outboxEvent.update({
        where: { id: ev.id },
        data: { status: "SENT", processedAt: new Date(), lastError: null },
      });
    } catch (err: any) {
      const attempts = ev.attempts + 1;
      const isDead = attempts >= ev.maxAttempts;
      const backoffMs = Math.min(3600_000, Math.pow(2, attempts) * 15_000);

      await prisma.outboxEvent.update({
        where: { id: ev.id },
        data: {
          attempts,
          status: isDead ? "DEAD_LETTER" : "FAILED",
          lastError: String(err?.message || err),
          nextRetryAt: new Date(Date.now() + backoffMs),
        },
      });
    }
  }
}
