import { Prisma } from "@prisma/client";
import { prisma } from "./prisma";

interface StockChangeItem {
  orderItemId: string;
  productId: string;
  variantId?: string | null;
  qty: number;
}

export async function deductStockAtomically(
  tx: Prisma.TransactionClient,
  orderId: string,
  displayNumber: string,
  items: StockChangeItem[]
) {
  const sorted = [...items].sort((a, b) => a.productId.localeCompare(b.productId));

  for (const item of sorted) {
    const idempotencyKey = `order:${orderId}:item:${item.orderItemId}:deduct`;
    const alreadyDeducted = await tx.stockMovement.findUnique({ where: { idempotencyKey } });
    if (alreadyDeducted) continue;

    if (item.variantId) {
      const lockedVariants = await tx.$queryRaw<Array<{ id: string; stock: number | null }>>`
        SELECT "id", "stock" FROM "ProductVariant" WHERE "id" = ${item.variantId} FOR UPDATE
      `;
      const v = lockedVariants[0];
      if (v && v.stock !== null) {
        if (v.stock < item.qty) {
          throw new Error(`ভ্যারিয়েন্টের পর্যাপ্ত স্টক নেই (চাহিদা: ${item.qty}, মজুদ: ${v.stock})`);
        }
        await tx.productVariant.update({
          where: { id: item.variantId },
          data: { stock: { decrement: item.qty } },
        });
      }
    }

    const lockedProducts = await tx.$queryRaw<Array<{ id: string; name: string; stock: number }>>`
      SELECT "id", "name", "stock" FROM "Product" WHERE "id" = ${item.productId} FOR UPDATE
    `;
    const prod = lockedProducts[0];
    if (!prod || prod.stock < item.qty) {
      throw new Error(`${prod?.name ?? "পণ্য"} — যথেষ্ট স্টক নেই`);
    }

    const updatedProd = await tx.product.update({
      where: { id: item.productId },
      data: {
        stock: { decrement: item.qty },
        soldCount: { increment: item.qty },
      },
    });

    await tx.stockMovement.create({
      data: {
        idempotencyKey,
        productId: item.productId,
        variantId: item.variantId ?? null,
        orderId,
        type: "OUT",
        qty: item.qty,
        balanceAfter: updatedProd.stock,
        note: `অর্ডার ${displayNumber}`,
      },
    });
  }
}

export async function restoreOrderStockAtomically(
  tx: Prisma.TransactionClient,
  orderId: string,
  reasonLabel: string
) {
  const order = await tx.order.findUnique({
    where: { id: orderId },
    include: { items: true },
  });
  if (!order) throw new Error("অর্ডার পাওয়া যায়নি");

  for (const item of order.items) {
    if (!item.productId) continue;
    const idempotencyKey = `order:${orderId}:item:${item.id}:restore`;

    const existingRestore = await tx.stockMovement.findUnique({ where: { idempotencyKey } });
    if (existingRestore) continue;

    if (item.variantId) {
      await tx.$queryRaw`SELECT "id" FROM "ProductVariant" WHERE "id" = ${item.variantId} FOR UPDATE`;
      await tx.productVariant.updateMany({
        where: { id: item.variantId, NOT: { stock: null } },
        data: { stock: { increment: item.qty } },
      });
    }

    await tx.$queryRaw`SELECT "id" FROM "Product" WHERE "id" = ${item.productId} FOR UPDATE`;
    const updatedProd = await tx.product.update({
      where: { id: item.productId },
      data: {
        stock: { increment: item.qty },
        soldCount: { decrement: item.qty },
      },
    });

    await tx.stockMovement.create({
      data: {
        idempotencyKey,
        productId: item.productId,
        variantId: item.variantId,
        orderId: order.id,
        type: "IN",
        qty: item.qty,
        balanceAfter: updatedProd.stock,
        note: `অর্ডার ${order.displayNumber} ${reasonLabel}`,
      },
    });
  }
}
