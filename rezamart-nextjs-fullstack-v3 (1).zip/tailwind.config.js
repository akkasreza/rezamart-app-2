/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        rm: {
          900: "#06281F",
          800: "#0A3A2D",
          600: "#13664E",
          200: "#CFE8DC",
          100: "#E8F3EE",
          sun: "#FFB400",
          sun2: "#E59A00",
          ink: "#13201A",
          mut: "#62716A",
          line: "#E1E8E4",
          bg: "#F4F6F4",
          red: "#D6382D",
          blue: "#2765B5"
        }
      },
      fontFamily: {
        anek: ["'Anek Bangla'", "sans-serif"],
        siliguri: ["'Hind Siliguri'", "'Noto Sans Bengali'", "sans-serif"],
      }
    },
  },
  plugins: [],
};
